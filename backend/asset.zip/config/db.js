const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'pplk2389_admin123',
    password: '7Y]XH]Mcd]D4',
    database: 'pplk2389_jurusan'
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to the database');
});

// Export database connection untuk digunakan di seluruh aplikasi
module.exports = db;
